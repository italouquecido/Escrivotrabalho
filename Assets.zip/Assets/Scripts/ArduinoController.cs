using UnityEngine;
using TMPro;
using BlueUnity; // Garante a leitura da pasta do plugin

public class ArduinoController : MonoBehaviour
{
    [Header("Configurações de UI")]
    public TMP_InputField inputFieldPalavra; 
    public TextMeshProUGUI statusText;

    void Start()
    {
        if (statusText != null) statusText.text = "Aguardando Bluetooth...";
    }

    public void EnviarTextoAoDigitar()
{
    if (inputFieldPalavra != null && BluetoothHandler.Instance != null)
    {
        // 1. Pegamos o texto e adicionamos o \n (quebra de linha)
        string textoParaEnviar = inputFieldPalavra.text + "\n";

        // 2. Convertemos para Bytes (O BlueUnity só aceita assim)
        byte[] dadosEmBytes = System.Text.Encoding.UTF8.GetBytes(textoParaEnviar);

        // 3. Enviamos usando o comando 'Write'
        BluetoothHandler.Instance.Write(dadosEmBytes);
        
        Debug.Log("Enviando: " + textoParaEnviar);
    }
}

public void FeedbackAcerto()
{
    BluetoothHandler.Instance.Write(
        System.Text.Encoding.UTF8.GetBytes("#CERTO\n"));
    if (statusText != null) statusText.text = "Acertou! LED Verde";
}

public void FeedbackErro()
{
    BluetoothHandler.Instance.Write(
        System.Text.Encoding.UTF8.GetBytes("*ERRADO\n"));
    if (statusText != null) statusText.text = "Errado! LED Vermelho";
}

}